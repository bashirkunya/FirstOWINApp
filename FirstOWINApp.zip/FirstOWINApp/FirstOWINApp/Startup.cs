﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Owin;

namespace FirstOWINApp
{
    class Startup
    {
        public void Configuration(IAppBuilder app)

        {

            app.Run(context =>

            {

                context.Response.ContentType = "text/html";

                return context.Response.WriteAsync("<h3><strong>My First Owin Application</strong></h3>");

            });

        }
    }
}
